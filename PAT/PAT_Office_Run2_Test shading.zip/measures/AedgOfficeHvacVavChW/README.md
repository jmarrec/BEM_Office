

###### (Automatically generated documentation)

# AedgOfficeHvacVavChW

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### This space type should be part of a ceiling return air plenum.

**Name:** ceilingReturnPlenumSpaceType,
**Type:** Choice,
**Units:** ,
**Required:** false,
**Model Dependent:** false

### Total Cost for HVAC System ($).

**Name:** costTotalHVACSystem,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Apply recommended availability and ventilation schedules for air handlers?

**Name:** remake_schedules,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false




